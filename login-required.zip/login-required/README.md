# "Login Required Simple Plugin" for WordPress
This is a super simple WordPress plugin tha defines a custom shortcode `[login_required]` that you can add to posts or pages in order to check if a user is logged in before letting them view the content. If they are not, it redirects them to the login screen. 

## Download 
You can download the .zip file from this repository: [login-required.zip](login-required.zip)
